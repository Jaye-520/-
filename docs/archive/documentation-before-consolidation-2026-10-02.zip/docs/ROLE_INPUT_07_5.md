# 07.5：官方UI教程复核与原生文字输入

日期：2026-10-02。用户07.4实测仍不能输入、希望立绘更大；截图保存screenshots/role-07-4-game-feedback.png。07.4输入验收失败，托管焦点补丁检查不能证明游戏输入可用。

## 官方资料与实测依据

重新从本游戏Mod/modFQA读取代码编写教程.docx、资源修改教程.docx中相关段落、代码示例Example.cs，以及资源修改教程/ResBuildABProject_Example/Assets/Example/10.UI（制作一个UI）/Resources/UI/TestExample.prefab。

官方资源教程明确要求：制作新预制体应复制例子中已设置参数/脚本的预制体；自定义UI通过g.ui.OpenUI打开、脚本继承UIBase，动态加载的Mono脚本需要代码AddComponent。这是完整自定义窗口的正规制作路径。当前没有Unity编辑器/新AssetBundle工程验证，因此本轮没有宣称迁移成了官方自定义预制体，而是复用已存在的游戏原生输入窗口。

读取真实Player.log：C:/Users/30718/AppData/LocalLow/guigugame/guigubahuang/Player.log。其中有07.4加载、203个原始/有效修士，以及Font..ctor(UnhollowerBaseLib.Il2CppStringArray,int)接口异常导致字体回退。没有搜索焦点守卫拦截日志；这不足以确定掉焦根因，字体异常也不能直接归为输入失败原因。此前只查MelonLoader日志未覆盖实际Unity运行日志。

核实本地Assembly-CSharp接口：UIType.ModTableInputStringLong；UIModTableInputStringLong.InitData(string title,string curValue,Il2CppSystem.Action<string> onOKCall,int maxLength)。其Base包含TMP_InputField piptValue、标题/占位/确认/关闭组件，使用完整游戏预制体和输入链路。

## 本轮交互与代码

- 名单上方搜索框现在是打开文字编辑窗口的按钮。点击后通过g.ui.OpenUI<UIModTableInputStringLong>打开原生窗口，传当前筛选和48字符上限。标题“搜索修士 · 留空显示全部”。确认后trim输入并筛选；取消保留当前查询；留空确认恢复全部。
- 已有同类型文字窗口时不覆盖它；回调先确认书卷仍存活且为角色页，避免关闭后向已销毁UI写入。打开原生文字窗口期间F8不关闭下方书卷。
- 移除手工InputField、每帧OnUpdateSelected补发和SearchFocusGuard.cs/编译条目；移除原窗口InitInputField额外注册，不再装载EventSystem焦点Harmony补丁。既有书卷、美术、原生窗口所有权仍保留。
- 人物放大30%：RawImage的UV宽高取1/1.3，水平居中、底边不动，裁去上方空白。保留07.4模型偏移和相机取景。超宽衣饰或个别人物可能发生侧边裁切，需实际核对。
- 原生搜索是确认后筛选，不再是在书卷内边输入边筛选。这是本轮明确交互变化，不能以原来的内联输入已修复描述。

## 验证与边界

构建零警告零错误，MOD_YtxSQ1/net472保持；没有新增程序集引用、修改存档或终止游戏。Release/debug DLL与PDB同步；DLL SHA256：351475F53E216C5D1C3D63F0A882CE98AAAF2E9BA250F51C2199B9D9878D7903。

本轮真实BookView配合替身的布局/原生对话框回调68项、生命周期8项通过，共76项。覆盖传当前值/上限、重复点击不替换窗口、取消保持、确认trim、清空恢复、选中NPC与页面/资源清理。替身仅模拟原生接口与回调，不模拟实际TMP、窗口层级、焦点、Windows IME或真实键入，F8的新原生窗口检查仅由正式编译验证，不将其写为实测通过。

07.4源码/产物备份.tools/role-07.5-baseline。模拟预览role-07-5-layout-*生成，不能证明原生输入窗口或实际立绘显示。

下一步：自行保存并重进MOD调试确认07.5，点击搜索打开原生文字窗口，测试中文输入/退格/粘贴/确认/取消/留空；核对书卷不在原生窗口打开后被卸载、确认后名单筛选，及原生窗口期间F8保护。检查人物放大后头部/衣饰不裁切。若原生窗口仍异常，优先读取上述Player.log的“原生搜索输入失败”，并核对窗口层级/字体/TMP，而非继续猜测EventSystem失焦。
