# 工程导航

核对日期：2026-10-02；依据07.13源码及ModMain.csproj。此处描述已存在的结构，未来模块划分见长期计划。

## 源码职责

以下路径相对工程根目录，源码根为`ModProject/ModCode/ModMain/`。

| 文件 | 当前职责 | 修改时关注 |
| --- | --- | --- |
| ModMain.cs | Init/Destroy、帧计时器、更新异常熔断 | 重复初始化、计时器停止与释放 |
| Core/WorkshopController.cs | 大地图条件、F8与编辑输入保护、窗口刷新 | 场景变化、其他窗口与输入隔离 |
| UI/WorkshopWindow.cs | UITextInfoLong承载、窗口所有权、开关与释放 | 共享原生窗口、失败回退、补丁释放 |
| UI/BookView.cs | 八模块布局、普通搜索、名单、角色属性、立绘及固定页脚 | 已认可布局；当前页脚不承载动态状态 |
| UI/WindowInputScope.cs | 搜索框无效焦点目标保护、光标整体平移、补丁生命周期 | 仅限本框，放行正常目标/null，关闭回滚 |
| UI/PaperSkin.cs | 宣纸、墨刷和山水纹理加载与释放 | 嵌入资源、纹理归属与释放 |
| Services/CharacterRoster.cs | 修士名单查询、过滤、去重 | 隐藏单位、死亡/无效数据、按需调用 |
| Services/CharacterReader.cs | 选中对象解析、上下文标识、只读快照和显示单位 | 字段真实getter、目标失效、跨存档清理 |
| Example/Example.cs | 工程中保留并参与编译的官方示例 | 不把示例能力当成产品功能 |
| Properties/AssemblyInfo.cs | 程序集元数据 | UI显示版本与程序集元数据分别核对，不假定自动同步 |

主调用关系：ModMain → WorkshopController → WorkshopWindow → BookView；BookView使用CharacterRoster/CharacterReader与PaperSkin，输入补丁由窗口生命周期管理。当前没有独立Modules目录或持久化写入服务；不得把计划中的结构当成已实现。

## 构建与资源

- `build.ps1`读取csproj明确列出的源文件、引用和嵌入资源，使用项目`.tools/`里的固定Roslyn与net472参考程序集。新增文件必须核对csproj，不能只保存源码。
- 主身份：命名空间及程序集`MOD_YtxSQ1`；目标net472；游戏新增程序集引用使用Private=False。
- 当前山水与标题墨刷位于源码`Art/`，以嵌入资源参与编译。`ModAssets`用于导出资源，不放工程笔记。
- Release：`ModProject/ModCode/ModMain/bin/Release/`；游戏调试：`debug/Mod_YtxSQ1/ModCode/dll/`。详细命令见[开发流程](DEVELOPMENT_WORKFLOW.md)。

## 官方资料定位

游戏根目录是本工程上两级目录；当前路径见项目记忆。

- 官方代码教程：游戏根`Mod/modFQA/代码编写教程/代码编写教程.docx`；资源教程：`Mod/modFQA/资源修改教程/资源修改教程.docx`，定位依据见[环境迭代](ITERATION_01.md)。
- 官方示例：源码`Example/Example.cs`；正式自定义UI路线的预制体位置见ITERATION_01，Unity2020.3.9/UIBase迁移尚未完成。
- 本地API缓存：`docs/api-reference/`；实际可调用签名需与游戏`MelonLoader/Managed/`程序集核对。CHM缓存和网上新版文档均不能替代本机核实。
- 输入、属性、名单和立绘的特殊约束见[错误复盘](UI_DEBUGGING_POSTMORTEM.md)。

新增服务优先接入现有边界，业务查询与写入不堆进BookView；抽象按实际需要增加，不为整理文档重构稳定代码。
