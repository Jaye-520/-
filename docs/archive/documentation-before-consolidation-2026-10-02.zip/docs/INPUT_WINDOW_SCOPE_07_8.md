# 07.8：隔离说明窗口键盘处理并跟踪实际失焦

日期：2026-10-02。用户确认07.7仍出现光标后瞬间消失。立绘保持认可状态。

## 已证实与未证实

当前Player.log确认加载UI/ModWorkshopUpload模板成功、模板自动编辑原本为True、运行版本07.7；随后出现两次搜索结束编辑且isFocused=False。因此07.7的自动编辑设置不是已证实根因，控件也并非无法开始编辑。

上一轮System.Environment.StackTrace只显示托管回调和Unhollower委托桥接，没有游戏原生调用者；不能把这份日志说成定位成功。现改从Il2CppSystem.Environment.StackTrace读取游戏栈，并在选择转移和DeactivateInputField入口观测。

本窗口借用UITextInfoLong，它与UIBase均有UpdateHandleInput方法。当前怀疑原说明窗口控制器与动态添加的输入冲突；只读本地程序集验证方法存在，未获得原生方法体或真实调用栈证明它确实是失焦来源。

## 当前实现

新增WindowInputScope：创建视图后给本窗口绑定搜索InputField，使用现有Harmony依赖，在UIBase/UITextInfoLong.UpdateHandleInput入口检查实例所有权和当前搜索状态。仅本窗口搜索被选中或编辑时跳过原窗口键盘处理，不停止EventSystem和InputField自己的编辑；其他窗口、切换模块隐藏搜索或点击其他控件时放行。

观测EventSystem.SetSelectedGameObject(GameObject,BaseEventData)及InputField.DeactivateInputField，只限本搜索处于选择/编辑期间，最多四次日志。观测补丁不拦截选择转移或正常结束编辑，不记录搜索字符串，不逐帧抢焦点。原生栈读取异常回退到有限错误信息，不让诊断破坏输入。

关闭、丢失窗口所有权、构建失败均解绑与UnpatchSelf；安装到一半失败时撤销已有补丁再由原布局回退处理。依赖Private=False、项目身份MOD_YtxSQ1保持。没有存档写入、游戏终止或立绘改动。

## 验证边界

正式编译零警告零错误。新增隔离检查8项：准确目标、非本窗口放行、待激活选择保护、连续窗口更新期间编辑保持、外部选择恢复、隐藏搜索放行、有限诊断、重复清理和部分安装失败撤销。生命周期8项通过，并增加关闭解绑条件。

这些检查执行真实隔离条件与清理代码，但Harmony与游戏为替身，不证明IL2CPP挂钩成功、原生输入冲突消除或中文IME实测通过。当前只可记“07.8隔离与诊断已交付”，不能记“输入已修复”。

下一步：游戏内确认07.8，核对日志“窗口输入隔离已安装”以及首次点击后的“已隔离本说明窗口的UpdateHandleInput”。若还失焦，读取“搜索焦点转移至”和“搜索DeactivateInputField”的游戏调用栈，依据实际调用者修正；若隔离日志没有出现，核查实际UIManager调用链与挂钩结果，勿再替换控件或调整立绘。
