# 迭代 01：构建与原生 UI 入口

日期：2026-10-02。状态：实现和编译完成；用户确认窗口显示、连续开关及重进游戏后显示正常，基础运行验证通过。其余场景待验证。不是正式美术交付。

## 官方依据

已读取 `Mod/modFQA/代码编写教程/代码编写教程.docx` 与 `资源修改教程/资源修改教程.docx` 的全文文本；图片未逐页核验。

- 代码教程要求 .NET Framework 4.7.2，推荐 VS 2022；主类为 ModMain，程序集和编辑器命名空间一致。
- 代码教程要求新增引用关闭复制到本地，通过编辑器“进入游戏调试”复制 Release 中的 DLL。
- `Example/Example.cs` 的 TestTimer 和 TestUI 提供计时器、原生文本窗口与自定义 UI 调用方式。
- 资源教程指定 Unity 2020.3.9；要求复制示例预制体再修改，UI 脚本继承 UIBase，并通过代码添加自定义组件。
- 已定位官方 `ResBuildABProject_Example/Assets/Example/10.UI（制作一个UI）/Resources/UI/TestExample.prefab`；正式 UI 下一步研究此预制体，未修改原文档或资源。
- 已通过 7-Zip 解包官方 GGBH_API.chm 到本地 `docs/api-reference/`，作为按需查阅缓存，忽略版本管理。
- 用游戏自带 Mono.Cecil 只读检查当前 Assembly-CSharp.dll 元数据，核实 UIMgr.GetUI/OpenUI/CloseUI/GetLayerTopUI、UITextInfoLong.InitData、UITypeBase.uiLayer 的实际签名；未运行或注入游戏代码。

## 构建环境结论

- PATH 未发现 dotnet 或现代 MSBuild，常规安装目录/已检查的 Unity App Paths 未发现 Unity；没有扫描整个硬盘，不能断言机器完全没安装。
- 系统 .NET 4.x MSBuild 尝试构建失败：缺少 4.7.2 引用程序集，部分模板引用失效，旧编译器无法读取某个 Unity 模块元数据。
- 项目内固定下载 NuGet 包：Microsoft.Net.Compilers.Toolset 4.8.0、Microsoft.NETFramework.ReferenceAssemblies.net472 1.0.3。来源为 api.nuget.org，存放 `.tools/`，不更改系统安装。
- 新增 build.ps1，直接读取 csproj 源文件和引用，用 Roslyn 编译；关闭默认编译器配置，显式引用 4.7.2 参考程序集，生成目标框架属性。
- 保持 csproj 可供现代 VS/MSBuild 使用；本轮验证的是 build.ps1，未验证现代 MSBuild 路线。
- 原始 ModMain.cs 与 csproj 已备份到 `.tools/baseline/`。

## 实现内容

- ModMain 管理计时器和施工控制器；重复 Init 先释放旧资源，Destroy 可重复调用。
- 当前没有业务 Harmony 补丁，移除模板中空 PatchAll 初始化；后续有实际补丁时再加入对应管理与释放。
- WorkshopController 使用大地图存在/激活状态作为场景条件；F8 为暂定技术验证键。
- 同层有其他 UI 时不抢占入口；正在编辑 Unity InputField 时不打开。其他输入组件、跨层弹窗与具体按键冲突仍需游戏验证。
- WorkshopWindow 沿用官方 UITextInfoLong，标注施工版和未实现功能；游戏已打开同类型窗口时不覆盖；清理按持有实例执行。
- 未访问角色数据、未写入存档、没有作弊或修改功能；正式玉符入口、快捷键配置和书卷 UI 尚未实现。
- 更新异常触发熔断并释放窗口，避免每帧刷日志；重进存档初始化可恢复。
- 清理模板无关/失效引用，保留必要游戏及 Unity 引用，Private=False；GameRoot 改为相对目录并可覆盖。

## 构建方法

在工程目录运行：

```powershell
.\build.ps1
```

游戏移动后可传 `-GameRoot '实际游戏目录'`。首次构建需要网络下载固定版本依赖，后续使用本地缓存。

编译先输出到 `.tools/build-output/`，成功且确认 Release 无额外 DLL 后才覆盖正式产物。失败时不能把旧 DLL 当成最新成功构建。

输出：`ModProject/ModCode/ModMain/bin/Release/MOD_YtxSQ1.dll` 和 PDB。依赖包与 CHM 缓存均位于 ModAssets 外，不随该目录导出。

## 验证结果

- 最终构建通过：零警告、零错误；启用 /warnaserror+。
- Cecil 核验程序集名 MOD_YtxSQ1、目标框架 .NETFramework,Version=v4.7.2、施工控制器与窗口类型均存在。
- 最终 DLL SHA256：`13097B5E07CC67368D1BE0B7BF737137E9C592FF7E9C3F0E617326F0468C4331`。
- Release 中仅有自身 DLL 和 PDB。
- 未自动复制到运行中的游戏，未重启游戏，未操作用户存档。观察到游戏进程正在运行，但没有读取其画面或确认编辑器状态。
- 用户随后提供 2560×1600 游戏截图，确认大地图背景上出现“八荒秘录 · 施工版”，正文、箭头、按钮中文可见，当前布局未见裁切。证据保存在 `screenshots/iteration-01-in-game.png`。
- 截图证明窗口已在游戏中显示及这张画面的文字呈现正常；不单凭静态截图认定 F8 触发方式、关闭、输入隔离、重复初始化或切换存档已通过。
- 用户进一步实测反馈：“连续的开关没问题，重进游戏也能正常显示面板”。记录为连续开关与重进游戏后显示通过；具体关闭方式、重复次数和重进路径未说明，不扩展推断。
- 输入隔离、其他 UI 共存、切换不同存档和离开大地图后的清理仍待验证。

## 游戏内验收步骤

1. 在模组编辑器打开本工程，确认代码命名空间为 MOD_YtxSQ1，点击“进入游戏调试”。
2. 在测试存档进入大地图，按 F8，确认出现“八荒秘录 · 施工版”，文字正常显示。
3. 按 F8、点击“合上秘录”、使用游戏原生关闭动作分别检查；连续开关不产生重复窗口。
4. 已有说明窗口、文字输入及其他 UI 打开时，检查是否覆盖或抢占；记录具体异常场景。
5. 退出存档再进入、切换测试存档、离开大地图，检查窗口残留和重复回调。
6. 如失败，记录操作路径与 MelonLoader/游戏日志中的 `[八荒秘录]` 信息。

## 下一步

基础入口运行验证已通过，可以推进迭代 02/03 的正式 UI 资源验证与角色页视觉样板；剩余场景纳入后续回归。确认实际 Unity 安装路径或准备 Unity 2020.3.9 后，按官方模板制作资源；不要用施工文本窗口代替最终精致界面。阶段 0 的自定义资源与组件验证仍未完成。
