# 07.9：查明失焦目标并停用原窗口导航

日期：2026-10-02。07.8再次游戏验收失败，用户已多次点击。

## 本次真实日志证据

Player.log内两次打开均显示07.8及“窗口输入隔离已安装”。四次记录的选择转移目标均为 `G:btnOK`，接着InputField.DeactivateInputField和结束编辑。这证明搜索被转移选择到确认按钮，不是无法激活、资源加载失败、验证器禁止文字或中文字体问题。

关键摘录：

```
[八荒秘录] 07.8窗口输入隔离已安装；仅限本窗口搜索
[八荒秘录] 搜索焦点转移至=G:btnOK
[八荒秘录] 搜索DeactivateInputField
[八荒秘录] 搜索结束编辑；isFocused=False
```

没有“已隔离本说明窗口的UpdateHandleInput”日志。因此07.8安装成功不能证明隔离分支执行，原先把竞争限定为该方法的假设不成立或至少没有抓住实际调用链。IL2CPP Environment.StackTrace在本机仍只给栈自身，不能称其成功提供原生调用者。

## 对照代码与接口

BookView此前只设置原图形enabled=false和原Button.interactable=false，按钮GameObject及原导航组件仍活动。UIOperationGroup继承MonoBehaviour，另有Update、UpdateGroup、UpdateOperation，以及isAutoSelect、m_isActiveOperation、uiBase、operationItems等状态。说明导航有独立更新入口，不能只补丁窗口UpdateHandleInput。

焦点目的对象已实测证实；尚未完整拿到具体调用者栈，导航组作为强制选择机制的定位是基于日志目的对象、残留组件和本地API的推断。不要写成已经取得导航组原生调用栈。

## 修改

- 停用原窗口按钮GameObject，保存原activeSelf与interactable，在释放视图时精确恢复，原来已隐藏按钮保持隐藏。
- WindowInputScope保存并停用承载窗口的导航：owner.isActiveOperation=false；子树和operationGroups缓存中的UIOperationGroup去重后enabled=false、isAutoSelect=false、m_isActiveOperation=false。仅本窗口的组，不变动其他窗口。
- 关闭或失败时恢复每组原值及窗口原操作状态；故障安装到一半也撤销。不会删除原组件，保证共享原生说明窗口可正常复用。
- 移除07.8无效的UIBase/UITextInfoLong.UpdateHandleInput补丁，只保留选择转移及DeactivateInputField的有限观测。没有全局选择拦截、逐帧重抢焦点或输入弹窗。
- 普通InputField、缓存过滤、41项属性和已认可立绘保持。

## 验证

正式构建零警告零错误。导航隔离8项：模拟原导航独立更新把搜索选中转移至G:btnOK并结束编辑，验证停用后连续30次更新不再转移；子树/缓存组去重、其他窗口保持、准确恢复原禁用状态、诊断限量、安装失败撤销。四画布布局/绑定68项、生命周期8项亦通过，共84项。

测试覆盖托管控制流和已观察到的冲突机制，不证明本机原生组已实际停用或键盘/IME游戏内成功。当前状态是07.9已交付待验收，07.8失败已确认。

下一步日志应显示“07.9已停用原窗口导航组=N”及组名。用户自行保存后重新调试，确认07.9，点击搜索并输入；若仍失焦，比较焦点目的对象是否仍为G:btnOK和实际停用组数量，核对是否还有窗口外导航持有按钮。不要再盲目更换输入框或改立绘。
