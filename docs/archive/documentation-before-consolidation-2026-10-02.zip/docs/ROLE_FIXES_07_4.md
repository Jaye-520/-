# 07.4：搜索焦点与立绘下移；考拉MOD目录核查

日期：2026-10-02。用户07.3实测反馈“问题都没有解决”，立绘希望再向下，搜索点击后立即失去焦点。截图保存screenshots/role-07-3-game-feedback.png。07.3只能记录编译/托管检查通过，搜索/立绘游戏验收明确未通过，不将之前的修复方案认定为已解决。

## 用户指定目录是否源码

只读检查目录：`C:/Users/30718/Downloads/3dmmods_【考拉】内置修改器V1.0.5.zip_id259154_fid374086/Mod_KLXGQ`。

- rg按扩展名检查没有找到.cs、.csproj、.sln或.pdb；找到ModCode/dll/MOD_KLXGQ.dll、ModRes/AssetBundle资源及ModExcel JSON配置。因此当前目录是编译后的MOD发布内容，不是原始源码工程。
- 使用Mono.Cecil读取DLL元数据/IL，没有加载执行其MOD逻辑。程序集MOD_KLXGQ，顶层类型95个，部分名字变为A.e/A.O等，说明至少部分符号经混淆。可以分析部分接口调用；反编译结果不等于原始源码，资源包也不等于Unity原工程。
- 针对立绘的有限IL证据：相关面板调用PortraitModel.CreateTexture(string,RawImage,Vector2,float,bool,CreateData)，偏移Vector2(0,-8)，尺寸参数1.2或1.5。参考该接口偏移思路，没有复制DLL、第三方美术或修改其目录，也没有安装/运行该MOD。
- 输入相关可见旧InputField/TMP_InputField与onValueChanged/onEndEdit绑定；没有证据证明它用了本项目当前的窗口承载方式。部分SetSelectedGameObject(null)出现在提交属性方法，不能据此认定它导致本项目掉焦。

## 本次实现

本地程序集确认UIBase.InitInputField为public。WorkshopWindow在BookView.Build后调用该原生输入注册接口，补上运行时创建控件后的扫描步骤；实际游戏注册效果仍待验证。

新增UI/SearchFocusGuard.cs：书卷创建时通过已有Harmony依赖挂钩EventSystem.SetSelectedGameObject两个重载，仅在本搜索框处于活动状态且为当前选中对象时，阻止非用户点击/提交导致的null选择。点击输入框外部、选择非null其他对象、回车/小键盘回车/Esc/Tab允许结束编辑；关闭解除本补丁，不影响其他控件。失败时记录警告并卸载已装部分补丁；最多记录两次拦截调用栈，供真实掉焦定位。尚未拿到触发清空的游戏调用栈，不宣称确证根因。

立绘自有ModelRenderTexture构造参数改为Vector2(0,-8)。相机取景中心上移模型高度12%，让人物在画面中下移；视野留边增至28%避免对应底部越界。该帧取景是否被原生渲染后续更新覆盖、静态立绘真实边界是否可靠仍需游戏验收；当前按用户“再往下点”要求局部改动，不重做属性布局。

## 验证

- 构建零警告零错误，身份MOD_YtxSQ1/net472保持，未新增程序集引用。
- 本轮布局/焦点守卫72项（原56项加四画布各4项）与窗口生命周期8项，共80项通过。覆盖自动null失焦阻止、外部点击/提交/其他对象放行、关闭解除补丁及人物下移后边界仍在视野。Harmony与Unity由托管替身模拟，不证明IL2CPP实际挂钩或Windows中文IME通过。生命周期测试新增InitInputField替身，使当前真实WorkshopWindow源码能执行。
- Release/debug DLL与PDB同步，DLL SHA256：930E211ED1C6A1A11373FBE53FD4842C6B70D9FC51BFA9B1F5A387BE9E3DCA4F。
- 07.3源文件与DLL/PDB备份.tools/role-07.4-baseline；模拟预览role-07-4-layout-*生成，不能证明立绘图像显示或真实键入成功。
- 未终止游戏、写入存档或运行下载的第三方DLL。

下一步：保存后自行重进MOD调试确认07.4；核对立绘下移、搜索框焦点/中文/退格/清空、外部点击与关闭恢复。如果仍失焦，读取当前实际游戏加载器日志里的“搜索焦点保护未加载”或“已拦截…空焦点切换”及调用栈，区分补丁加载失败、非null焦点替换、OnDeselect调用或窗口生命周期变化。不要再以托管检查通过断言游戏问题已解决。
