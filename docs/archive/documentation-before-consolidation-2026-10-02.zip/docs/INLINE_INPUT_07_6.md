# 07.6：恢复普通内联输入框

日期：2026-10-02。用户明确拒绝07.5弹窗搜索，要求普通输入框并要求上网查资料；同时明确立绘大小已经合适。07.5绕开需求属于实现方向错误，不能继续当作输入功能完成。

## 网络资料与本地核对

检索Unity输入焦点/TMP和鬼谷八荒MOD输入框资料；游戏专用公开搜索未找到可直接核验的官方输入实现。采用Unity官方[TMP_InputField 3.0.6接口文档](https://docs.unity3d.com/Packages/com.unity.textmeshpro@3.0/api/TMPro.TMP_InputField.html)和[官方组件源码](https://github.com/Unity-Technologies/uGUI/blob/main/com.unity.ugui/Runtime/TMP/TMP_InputField.cs)了解文字组件、textViewport、变化事件、焦点与编辑配置。main源码可能比游戏更新，因此所有实际使用成员还用本地Unity.TextMeshPro.dll元数据及正式构建核对。

结合本地官方教程“复用配置好的预制体”方向，本轮只从游戏UIType.ModTableInputStringLong对应资源的TMP_InputField子对象复制输入控件，而非打开文字窗口。路径根据uiName构造UI/前缀，通过g.res.Load<GameObject>取得模板；该实际资源加载与点击仍须游戏验证，托管模拟不证明游戏资源路径已加载成功。

## 实装

- 删除搜索按钮、OpenSearchEditor及原生确认弹窗调用。直接在左栏搜索位置嵌入TMP_InputField子预制体，保留字体、文字组件、裁切视口、光标及其层级配置。
- 配置单行Standard、无字符校验、48字符上限、可编辑；缩放根控件到原搜索框36高，textViewport自适应并留8/4边距，字体17。保留游戏原输入字体，不依赖OS字体构造接口。
- 将onValueChanged/onSubmit/onEndEdit/onSelect/onDeselect替换成新事件，避免继承模板中指向其他面板的事件；输入变化立即筛选缓存名单，清空立即恢复。仅搜索比较时trim，不主动重写输入字符串或打断IME组合。
- 不安装焦点Harmony补丁、不手工PopEvent或拼接Input.inputString、不弹窗。控件建立后调用原窗口InitInputField更新注册；F8防护识别TMP_InputField.isFocused。
- 记录“内联输入模板”资源路径和“内联搜索已选中”，便于区分模板加载失败与点击链路问题，不记录输入内容。
- 新增本地Unity.TextMeshPro引用，Private=False，不复制游戏DLL进Release/debug。
- 人物立绘UV缩放、相机位置、模型偏移全部保持07.5，用户已经认可大小，不再调整。

## 验证与边界

构建零警告零错误。Release/debug DLL及PDB同步，DLL SHA256：074E2FD9FD434FDC4DC1B6D5ED711162CB81DAEE7A928581D17612671E1562C2。工程身份MOD_YtxSQ1/net472保持；无存档写入、无游戏终止。

本轮四画布布局/输入绑定60项与生命周期8项通过，共68项。验证TMP模板含文字与视口、输入直接触发筛选/不打开弹窗、旧模板监听器被替换、空文本恢复名单、选中NPC及关闭清理。游戏资源、TMP帧行为、鼠标点击和中文IME是替身，不能以这些测试断言真实游戏输入已解决。F8的TMP检测由正式编译验证，未记为游戏实测通过。

备份07.5代码/产物在.tools/role-07.6-baseline。模拟布局预览role-07-6-layout-*生成，GDI不完整模拟TMP文字，不作为输入框实际视觉验收。

下一步：自行保存并重进调试确认07.6。点击框内直接输入中文姓名，核对光标、键入/组合候选/退格/粘贴/清空和即时筛选、点击其他控件结束编辑；确认无弹窗，搜索时F8不关闭。若仍异常，读取AppData/LocalLow/guigugame/guigubahuang/Player.log，先核对模板加载路径与“内联搜索已选中”日志，再分析实际输入模块；不可继续擅自改成弹窗来替代普通输入需求。
