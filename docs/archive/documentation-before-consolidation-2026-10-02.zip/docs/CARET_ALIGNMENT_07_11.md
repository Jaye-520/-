# 07.11：输入光标对齐

2026-10-02：用户确认07.10输入成功，截图搜索“乐”显示4/203名修士；但光标下端偏低。这个实测仅证明该中文字符输入与筛选，不覆盖粘贴、复杂IME、连续开关窗口等全部输入行为。

Player.log实测保护命中 `Game/UIRoot/Canvas/Root/UI/TextInfoLong/Root/btnGroup/G:btnOK`，active=False、可交互=False。现在可以确定之前失焦目标属于承载说明窗口，且是停用按钮；完整强制选择的调用者栈依然未取得。

保持07.10成功的焦点保护、原模板、布局和立绘。仅在BookView输入组件中统一文字与占位文字的中间左对齐、lineSpacing=1、alignByGeometry=false、中心pivot与单位scale；控件激活后调用本机已存在的AssignPositioningIfNeeded与UpdateLabel同步原生光标矩形及文字缓存。不手动偏移光标网格或新增焦点补丁。

依据[Unity InputField组件源码](https://github.com/Unity-Technologies/uGUI/blob/main/com.unity.ugui/Runtime/UGUI/UI/Core/InputField.cs)：光标使用TextGenerator行的topY/height，光标RectTransform需同步文字位置、尺度、锚点和pivot。网络main可能新于本机，仅用作机制参考，本次实际成员通过本机编译验证。当前尚未取得模板原始行距和几何对齐的运行数值，因此不能写成已证实某一个参数就是光标偏低的唯一原因。

正式编译零警告零错误，原四画布布局/绑定68项检查通过。替身不模拟字体行度量或光标网格，光标是否已视觉对齐仍需游戏截图验收。Release/debug DLL/PDB同步，项目身份和Private=False保持，无存档写入或游戏终止。
