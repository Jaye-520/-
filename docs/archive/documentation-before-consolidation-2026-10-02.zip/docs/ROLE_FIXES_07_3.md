# 07.3：立绘取景与搜索输入

日期：2026-10-02。当前截图保存为screenshots/role-07-2-game-feedback.png；用户确认07.2立绘位置不对、点击搜索框后不能正常输入。截图另确认名单203人、玩家暴击200%、属性下移均已显示，不能因此断言名单完整或全部属性正确。

## 实现

- 移除经验缩放除数180。创建模型与ModelRenderTexture后，读取已启用且处于活动状态的Renderer世界bounds，合并有效边界；相机XY移至边界中心，保留游戏创建的Z位置。正交范围同时满足高度与宽高比，并增加8%留边。通过本地程序集确认ModelRenderTexture.camera可访问。若没有有效Renderer/相机则清理资源并提示不可用，不继续展示误裁切躯干。
- 搜索框在inactive状态组装Text与InputField，设置targetGraphic、单行Standard内容类型、无字符验证、可编辑/可交互、可见光标，再激活；文字使用横向Overflow以便单行编辑。
- 已聚焦且是当前EventSystem选中对象的搜索框，在每帧RefreshCharacter开始处调用OnUpdateSelected，早于数值一秒节流。它作为游戏输入模块不派发UpdateSelected时的补充；InputField消耗事件队列，正常模块重复调用不追加第二份字符。未创建第二套EventSystem，也不自行拼接Input.inputString或IME组合串。F8保护沿用既有输入焦点检测。
- 输入问题的具体游戏原因尚未取得日志证据，上述初始化与事件补充分支是修复方案，不将其写为已确证根因。真实鼠标焦点、中文IME、快捷键与地图输入隔离仍待游戏验证。

依据：本游戏UnityEngine.UI与Assembly-CSharp元数据及Unity官方[InputField源码](https://raw.githubusercontent.com/Unity-Technologies/uGUI/main/com.unity.ugui/Runtime/UGUI/UI/Core/InputField.cs)，后者用于理解事件消耗和焦点路径，不作为本地版本完全相同的证明。没有修改原游戏相机，只调整本修改器新建的立绘渲染相机。

## 验证与产物

BookView与布局托管检查改变；角色读取、名单与生命周期服务未改。构建零警告零错误。Release/debug DLL与PDB同步，DLL SHA256：F21732B3992B0D5DA68C6397A6C03102D18507F958717C451D4A0AC21C29C920。

本轮run-book-layout.ps1共56项通过：原44项，加四画布各3项，验证偏离原点模型完整落入相机XY视野、输入可编辑配置、已聚焦中文键盘事件在节流前只处理一次。模拟数据/输入事件不模拟Windows中文IME、实际点击/Unity帧事件顺序或游戏渲染，不能代替游戏验收。模拟预览role-07-3-layout-*生成，布局沿用07.2，不宣称预览已经显示立绘。

施工前07.2代码与产物备份.tools/role-07.3-baseline。本次未终止游戏或写入实际存档。

## 游戏验收

保存后自行退出并重进MOD调试，确认07.3。

1. 点击搜索框，有光标并可输入中文姓名/部分名字；测试英文、退格、粘贴、清空、无结果；中文候选确认后才筛选，不能重复字符。点击名单后输入焦点正常退出，搜索时F8不关闭。
2. 自己和不同NPC立绘完整显示，头部、脚部、宽衣饰不被误裁切，位置随模型变化仍居中；连续切人物无残留。
3. 检查搜索时不操作后方地图；切模块/关闭释放输入与立绘，重新打开可继续输入，切存档不保留旧目标。

若仍无法输入，下一步需要实际游戏事件模块/焦点日志，不能凭托管测试宣称解决；若模型没有Renderer，分析游戏静态立绘的实际组件类型再适配边界来源。
