# 07.7：按鬼谷 MOD 实际源码初始化普通输入框

日期：2026-10-02。07.6 已被用户视频明确否定，不能记为输入功能完成。人物大小已认可，本轮保持其相机、模型偏移和 UV 设置。

## 实际证据

- 查看用户视频 PixPin_2026-10-02_16-15-56.mp4：点击搜索后仍显示占位文字，没有可确认的键入效果。使用工具提取帧，不执行第三方 MOD。
- 当前 Player.log 有大量“内联搜索已选中”，证明选中事件发生，不证明进入编辑或持续获得焦点。仅凭这一日志不能断言是谁取消了焦点。
- 专门搜索鬼谷 MOD 输入框，并读取公开工程源码：
  - [GuiGuBaHuang-ModLib / UISampleHelper](https://github.com/4azuo/GuiGuBaHuang-ModLib/blob/main/3385996759/ModProject/ModCode/ModLib/Helper/UISampleHelper.cs)：从 UIModWorkshopUpload.iptDesc 复制 UnityEngine.UI.InputField 模板。
  - [CompHelper](https://github.com/4azuo/GuiGuBaHuang-ModLib/blob/main/3385996759/ModProject/ModCode/ModLib/Helper/CompHelper.cs)：控件复制后删除 EventTrigger；输入字段清除 onValidateInput、重置事件、Standard、shouldActivateOnSelect=true。
  - UICustom1 同样使用 UITextInfoLong 作为承载窗口；该公开工程未在添加输入控件后再调用 InitInputField。
- 上述是第三方作者源码，不是官方教程或本机游戏实测。其控件初始化模式结合本地官方复用预制体方向使用，不安装/执行其 MOD 或复制整套框架。
- 实际编译发现本机 TMP_InputField 没有新版 shouldActivateOnSelect 属性，而普通 InputField 有。网上新版 Unity TMP 接口不能直接套用本机游戏。

## 修改

- 从 UIType.ModWorkshopUpload 对应的游戏资源复制普通 InputField 子对象，嵌入既有左栏位置；保留游戏字体与普通输入框编辑行为。当前选取模板内第一个普通输入控件，未通过打开上传界面提取组件。
- 克隆对象配置期间停用；删除克隆子树上的 EventTrigger，先禁用使延迟销毁前不会执行。替换文字变化/结束编辑事件、清除验证器，明确启用 shouldActivateOnSelect，单行、48 字上限。
- 文字和占位文字取消射线拦截，自动铺满搜索框；沿用原边框。输入变化直接筛选，比较时 trim，不重写实际编辑内容或截获 IME。
- 移除追加的 ownedWindow.InitInputField 调用，避免又给控件附加原窗口输入代理。这是根据公开实现作出的修正，尚无本机证据证明该调用就是根因。
- 不补丁拦截全局焦点，不每帧抢焦点，不手工派发文字，不弹出编辑窗口。
- 删除反复选中日志；结束编辑最多记录两次状态/调用栈，不记录查询内容。若仍失焦，依据新日志调查实际触发路径。

## 验证与交付

正式构建零警告零错误。布局/绑定检查 64 项与生命周期 8 项通过，共 72 项。新增回归条件：模板初始不自动编辑、有验证器和事件代理；初始化必须启用自动编辑、清理验证器、停用代理并替换旧回调。四画布属性/人物/模块切换和清空恢复保持通过。

这些是托管替身测试，不验证实际鼠标、键盘、剪贴板或中文 IME。07.7 游戏资源加载、持续焦点和实际输入仍待游戏验收，不能提前写“已解决”。

Release/debug DLL 与 PDB 已同步。DLL SHA256：0A9C55BA7EDF7ABD6BAA026386F5D447F6477A056A40B9FEE6F67CE64C930B17。工程身份 MOD_YtxSQ1/net472 与 Private=False 保持，无存档写入或游戏终止。

下一步：用户自行保存并重进调试，确认右下角 07.7。核对点击后光标、连续输入中文/英文、退格、粘贴、清空恢复、点击其他控件结束编辑。若仍失败，优先读取 Player.log 的模板加载/结束编辑日志，禁止继续盲改立绘或改成弹窗。
