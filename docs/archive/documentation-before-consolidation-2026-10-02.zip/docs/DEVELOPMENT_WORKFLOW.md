# 开发与交付流程

更新：2026-10-02。适用于当前MOD工程；这是工作约定，不是已完成的自动化能力。

## 开始一个小迭代

1. 先读PROJECT_MEMORY与LONG_TERM_PLAN；查相关源码、官方资料和本机接口。UI排查先读错误复盘。
2. 明确一个可独立验收的目标、相关模块及范围，使用[模板](templates/ITERATION_TEMPLATE.md)记录。普通实现自主判断，不重复请求已授权事项。
3. 检查当前产物与工作区变更。保护已认可美术、普通搜索、立绘、光标和固定署名；需要改变稳定实现时给出新问题与证据。
4. 在覆盖代码/产物前保留可恢复的相关源码、工程配置及原DLL；记录版本、日期和SHA256。备份放工程`.tools/backups/<日期-版本>/`，不放ModAssets。该目录是约定，不表示已有完整备份。

2026-10-02在工作区与工程目录未发现Git仓库。当前不能声称有提交历史可回退；后续如启用Git，先检查现有目录、忽略规则和本地改动，不把游戏/工具缓存/存档或秘密加入仓库。普通文档整理无需重新构建或同步DLL。

## 实现、构建与同步

下面命令在`ModProject_YtxSQ1`目录运行。构建失败会停止，build.ps1成功前不会覆盖上次Release产物。

```powershell
$ErrorActionPreference = 'Stop'
& ./build.ps1
Copy-Item -LiteralPath ./ModProject/ModCode/ModMain/bin/Release/MOD_YtxSQ1.dll -Destination ./debug/Mod_YtxSQ1/ModCode/dll/MOD_YtxSQ1.dll -Force
Get-FileHash -LiteralPath ./ModProject/ModCode/ModMain/bin/Release/MOD_YtxSQ1.dll,./debug/Mod_YtxSQ1/ModCode/dll/MOD_YtxSQ1.dll -Algorithm SHA256
```

- 保持身份与net472不变，新增游戏引用Private=False；新增源码/资源登记到csproj。
- Release不混入多余DLL。需要调试符号时单独核对PDB及编辑器同步规则，不能把07.13的DLL同步记录写成PDB也已同步。
- 官方编辑器“进入游戏调试”会复制Release DLL并加载；手动复制只证明磁盘同步，不证明进程已重载。按运行版本日志、实际界面及用户反馈记录加载证据。
- 不自动终止游戏，不擅自写实际存档。写入功能先研究字段依赖，再在测试存档验证；持久写入与临时开关分开描述。

## 验证与问题处理

按[验证矩阵](VALIDATION_MATRIX.md)选相关项；只运行与改动相称的现有脚本。托管替身不覆盖IL2CPP、Unity事件顺序和Windows IME。旧检查脚本使用前核对是否仍适配当前源码，失败如实记录。

同一症状连续两次修复失败，先增加真实事件证据；区分事实、假设和证据缺口。不逐帧抢焦点、不以模拟数据自证属性单位。游戏反馈失败时保留该版本失败结论，修复后另记结果。

## 完成与知识维护

| 文档 | 更新规则 |
| --- | --- |
| PROJECT_MEMORY.md | 唯一当前基线、现状、约束、证据摘要和下一步；替换过时结论，不累计多个“最新” |
| LONG_TERM_PLAN.md | 路线、功能范围、阶段门槛；当前进度只链接项目记忆，避免重复维护细节 |
| docs/README.md | 阅读入口、新记录索引及历史标识 |
| 版本迭代记录 | 日期、目标、文件、依据、编译/同步/运行分别记录、用户反馈、边界与下一步 |
| ARCHITECTURE.md | 实际结构发生变化时更新；不把拟建目录描述为存在 |
| VALIDATION_MATRIX.md | 证据变化时更新；后续通过不得抹掉历史失败与未覆盖项 |
| UI_DEBUGGING_POSTMORTEM.md | 新的可复用失误、证据和预防规则；避免记录无依据猜测 |

状态使用：未开始、研究中、实现中、待游戏验证、已验收、延期。验收须标明范围；用户“完美/搞定了”可以确认当轮问题，不等于全模块或多分辨率通过。已验收项从阻塞待办中移除，广泛回归保留在矩阵。

文档变更完成后核对本地链接、版本一致性、证据出处和实际路径。历史记录保留原日期与事实，新加阅读提示即可，不随意移动导致旧链接失效。
